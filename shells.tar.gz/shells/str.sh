#!/bin/bash

STR="Have a nice day!!"
echo $STR

